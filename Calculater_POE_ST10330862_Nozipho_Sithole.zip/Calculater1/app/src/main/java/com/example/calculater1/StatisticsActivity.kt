package com.example.calculater1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StatisticsActivity : AppCompatActivity() {

    private val maxNumber = 10
    private val numbersArray = IntArray(maxNumber)
    private var currentCount = 0

    private lateinit var numbersEditText: EditText
    private lateinit var displayTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)

        // Initialize UI components
        numbersEditText = findViewById(R.id.numbersEditText)
        displayTextView = findViewById(R.id.displayTextView)
        val arrayTextView: TextView = findViewById(R.id.arrayTextView)

        // Button to add a number to the array
        val addButton: Button = findViewById(R.id.addButton)
        addButton.setOnClickListener {
            addNumber()
            updateArrayDisplay(arrayTextView)
        }

        // Button to clear the array
        val clearButton: Button = findViewById(R.id.clearButton)
        clearButton.setOnClickListener {
            clearArray(arrayTextView)
        }

        // Button to calculate and display the average
        val averageButton: Button = findViewById(R.id.averageButton)
        averageButton.setOnClickListener {
            calculateAverage()
        }

        // Button to find and display the minimum and maximum values
        val minMaxButton: Button = findViewById(R.id.minMaxButton)
        minMaxButton.setOnClickListener {
            findMinMax()
        }
    }

    private fun updateArrayDisplay(arrayTextView: TextView) {
        val numbersString = numbersArray.take(currentCount).joinToString(", ")
        arrayTextView.text = "$numbersString"
    }

    private fun addNumber() {
        if (currentCount < maxNumber) {
            val number = numbersEditText.text.toString().toIntOrNull()
            if (number != null) {
                numbersArray[currentCount] = number
                currentCount++
            }
        }
    }

    private fun clearArray(arrayTextView: TextView) {
        currentCount = 0
        numbersArray.fill(0)
        updateDisplay()
        updateArrayDisplay(arrayTextView)
    }

    private fun calculateAverage() {
        val sum = numbersArray.take(currentCount).sum()
        val average = if (currentCount > 0) sum.toDouble() / currentCount else 0.0
        displayResult("Average: ${"%.2f".format(average)}")
    }

    private fun findMinMax() {
        val min = numbersArray.take(currentCount).minOrNull() ?: 0
        val max = numbersArray.take(currentCount).maxOrNull() ?: 0
        displayResult("Minimum: $min, Maximum: $max")
    }

    private fun updateDisplay() {
        val numbersString = numbersArray.take(currentCount).joinToString(", ")
        displayTextView.text = "$numbersString"
    }

    private fun displayResult(result: String) {
        displayTextView.text = result
    }

}

