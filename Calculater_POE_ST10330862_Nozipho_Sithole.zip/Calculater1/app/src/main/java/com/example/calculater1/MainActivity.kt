package com.example.calculater1

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private var input1: TextView? = null
    private var input2: TextView? = null
    private var answer: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input1 = findViewById(R.id.input1)
        input2 = findViewById(R.id.input2)
        answer = findViewById(R.id.tvAnswer)

        val addBtn = findViewById<Button>(R.id.addBtn)
        val subBtn = findViewById<Button>(R.id.subBtn)
        val mulBtn = findViewById<Button>(R.id.mulBtn)
        val divBtn = findViewById<Button>(R.id.divBtn)
        val sqrBtn = findViewById<Button>(R.id.sqrBtn)
        val powBtn = findViewById<Button>(R.id.powBtn)
        val statBtn = findViewById<Button>(R.id.statBtn)

        addBtn.setOnClickListener {
            add()
        }

        subBtn.setOnClickListener {
            subtract()
        }

        mulBtn.setOnClickListener {
            multiply()
        }

        divBtn.setOnClickListener {
            divide()
        }

        sqrBtn.setOnClickListener {
            squareRoot()
        }

        powBtn.setOnClickListener {
            power()
        }

        statBtn.setOnClickListener {
            intent = Intent(this, StatisticsActivity::class.java)
            startActivity(intent)
        }


    }


    private fun add() {
        if (isNotEmpty()) {
            val num1 = input1?.text.toString().trim().toDouble().toInt()
            val num2 = input2?.text.toString().trim().toDouble().toInt()

            val result = num1 + num2

            answer?.text = "$num1 + $num2 = $result"
        }
    }


    private fun isNotEmpty(): Boolean {

        var isValid = true
        if (input1?.text.toString().trim().isEmpty()) {

            input1?.error = "Required"
            isValid = false
        }

        if (input2?.text.toString().trim().isEmpty()) {

            input2?.error = "Required"
            isValid = false
        }
        return isValid
    }

    private fun subtract() {
        if (isNotEmpty()) {
            val num1 = input1?.text.toString().trim().toDouble().toInt()
            val num2 = input2?.text.toString().trim().toDouble().toInt()

            val result = num1 - num2

            answer?.text = "$num1 - $num2 = $result"
        }
    }

    private fun multiply() {
        if (isNotEmpty()) {
            val num1 = input1?.text.toString().trim().toDouble().toInt()
            val num2 = input2?.text.toString().trim().toDouble().toInt()

            val result = num1 * num2

            answer?.text = "$num1 * $num2 = $result"

        }
    }

    private fun divide() {
        if (isNotEmpty()) {
            val num1 = input1?.text.toString().trim().toDouble().toInt()
            val num2 = input2?.text.toString().trim().toDouble().toInt()

            val result: String

            if (num2 != 0) {
                result = "$num1 / $num2 = ${num1 / num2}"
            } else {
                result = "Error: Division by zero"
            }

            answer?.text = result
        }
    }


    private fun squareRoot() {
        if (isNotEmpty()) {
            val num1 = input1?.text.toString().trim().toDouble()

            if (num1 >= 0) {
                val result = sqrt(num1).toInt()
                answer?.text = "sqrt($num1) = $result"
            } else {
                val result = sqrt(-num1).toInt()
                answer?.text = "sqrt(-$num1) = ${result}i"
            }
        }
    }



    private fun power() {
        if (isNotEmpty()) {
            val num1 = input1?.text.toString().trim().toDouble().toInt()
            val num2 = input2?.text.toString().trim().toDouble().toInt()

            val result = num1.toDouble().pow(num2).toInt()

            answer?.text = "$num1^$num2 = $result"
        }
    }


}
